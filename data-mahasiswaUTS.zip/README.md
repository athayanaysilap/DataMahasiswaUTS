# 🎓 BlueStudent - Sistem Manajemen Data Mahasiswa

Aplikasi web modern berbasis **HTML, CSS, PHP Native, dan MySQL** yang dikembangkan untuk tugas individu mata kuliah **Web Project** (pengembangan lanjutan dari proyek POS Minimart).

---

## 🌟 Fitur Utama Aplikasi

1. **Dashboard Akademik Modern**
   - Kartu statistik dinamis: Total Mahasiswa, Total Jurusan, Data Baru Ditambahkan, Status Koneksi Database.
   - Tabel ringkasan 5 mahasiswa terbaru dengan badge program studi berwarna.
   - Visualisasi grafik batang (Bar Chart) distribusi mahasiswa per jurusan menggunakan **Chart.js**.
   - Kartu informasi lingkungan server Laragon & MySQL.

2. **Manajemen Data Mahasiswa (CRUD Lengkap)**
   - **Create**: Formulir penambahan mahasiswa dengan validasi server-side dan pengecekan duplikasi NIM.
   - **Read**: Tabel data mahasiswa dengan kolom No, NIM, Nama, Jurusan, Email, Tanggal Ditambahkan, dan Tombol Aksi.
   - **Update**: Edit data mahasiswa dengan form auto-fill terisi otomatis dan validasi NIM unik.
   - **Delete**: Hapus data mahasiswa secara aman dengan modal dialog konfirmasi.

3. **Pencarian & Filter Terpadu**
   - Pencarian cepat multi-kolom berdasarkan **NIM** atau **Nama Mahasiswa**.
   - Filter dropdown dinamis berdasarkan **Program Studi / Jurusan**.
   - Sistem **Pagination** otomatis dengan batas tampilan rapi.

4. **Standar Keamanan Kode**
   - **SQL Injection Prevention**: Menggunakan `mysqli` dengan **Prepared Statements** (`prepare`, `bind_param`, `execute`).
   - **XSS Prevention**: Melindungi output browser dengan `htmlspecialchars(..., ENT_QUOTES, 'UTF-8')`.
   - **Input Sanitization**: Fungsi pembersih data pada `koneksi.php`.

5. **Desain UI/UX Premium Blue Gradient**
   - Palet warna: Deep Navy (`#0B1F4D`), Royal Blue (`#1D4ED8`), Bright Blue (`#3B82F6`), Sky Blue (`#7DD3FC`), Background (`#F4F7FC`), Card (`#FFFFFF`).
   - Sudut melengkung halus (*rounded 14–20px*), bayangan lembut (*soft shadows*), dan tipografi modern (Plus Jakarta Sans & Poppins).
   - Responsive layout untuk desktop, tablet, dan smartphone.

---

## 📁 Struktur Berkas Proyek

```text
data-mahasiswa/
├── assets/                  # Folder aset tambahan (ikon / gambar jika diperlukan)
├── includes/
│   ├── header.php           # Template header, top navigation, & breadcrumb
│   ├── sidebar.php          # Template sidebar navigasi BlueStudent
│   └── footer.php           # Template modal hapus, script loader, & penutup
├── database.sql             # Skrip SQL pembuatan database & data awal (10 sampel)
├── koneksi.php              # Konfigurasi koneksi MySQL (auto-setup & prepared statements)
├── index.php                # Entry point aplikasi (otomatis redirect ke dashboard)
├── dashboard.php            # Halaman Dashboard statistik & grafik jurusan
├── mahasiswa.php            # Halaman tabel kelola data mahasiswa (Read, Search, Pagination)
├── tambah.php               # Halaman form tambah mahasiswa (Create)
├── edit.php                 # Halaman form edit mahasiswa (Update)
├── hapus.php                # Skrip pemrosesan hapus data (Delete)
├── pengaturan.php           # Halaman informasi aplikasi, profil admin, & panduan teknis
├── logout.php               # Halaman logout & penutupan sesi
├── style.css                # Kustomisasi CSS tema Blue Gradient & responsivitas
├── script.js                # Skrip interaktivitas modal konfirmasi & mobile toggle
└── README.md                # Dokumentasi lengkap proyek
```

---

## 🚀 Panduan Menjalankan Aplikasi di Laragon

### Langkah 1: Jalankan Laragon
1. Buka aplikasi **Laragon** di komputer Anda.
2. Klik tombol **"Start All"** untuk menjalankan service **Apache** dan **MySQL**.

### Langkah 2: Mengimpor Database ke phpMyAdmin
1. Pada jendela Laragon, klik tombol **"Database"** atau buka browser ke alamat:
   ```
   http://localhost/phpmyadmin/
   ```
2. Klik tab **"Import"** di bagian atas menu phpMyAdmin.
3. Klik tombol **"Choose File"** (Pilih Berkas), lalu pilih file:
   ```
   C:\laragon\www\data-mahasiswa\database.sql
   ```
4. Gulir ke bawah dan klik tombol **"Go"** / **"Impor"**.
5. Database `db_mahasiswa` beserta tabel `mahasiswa` dan 10 data awal sampel akan otomatis terbentuk.

> 💡 **Fitur Cerdas Auto-Init:** `koneksi.php` juga telah dilengkapi dengan skrip pendeteksi otomatis. Jika Anda langsung membuka website sebelum impor manual, sistem akan secara otomatis mencoba membuat database `db_mahasiswa` dan tabel `mahasiswa` beserta sampel datanya!

### Langkah 3: Buka Aplikasi di Browser
Buka browser favorit Anda (Google Chrome, Edge, atau Firefox) lalu ketikkan URL:
```
http://localhost/data-mahasiswa/
```
Aplikasi siap digunakan dan dipresentasikan!

---

## 🎙️ Panduan Presentasi & Poin Penjelasan Video Tugas

Saat merekam video presentasi tugas, Anda dapat menjelaskan alur proyek dengan urutan berikut:

1. **Pengenalan Singkat**:
   - Jelaskan bahwa aplikasi ini bernama **BlueStudent**, pengembangan dari proyek POS Minimart dengan fokus pada pengelolaan data entitas mahasiswa.
   - Tunjukkan tema desain **Blue Gradient** yang profesional dan bersih.

2. **Koneksi Database (`koneksi.php`)**:
   - Jelaskan bahwa koneksi menggunakan ekstensi `mysqli` PHP yang terhubung ke server MySQL lokal Laragon (`localhost`, user `root`, tanpa password, database `db_mahasiswa`).
   - Jelaskan fungsi sanitasi input `cleanInput()` untuk mencegah serangan XSS.

3. **Dashboard (`dashboard.php`)**:
   - Tunjukkan kartu metrik: perhitungan dinamis `COUNT(*)` untuk total mahasiswa dan `COUNT(DISTINCT jurusan)` untuk total jurusan.
   - Tunjukkan visualisasi grafik batang yang di-render dinamis menggunakan Chart.js berdasarkan data `GROUP BY jurusan`.

4. **Operasi CRUD**:
   - **Create (`tambah.php`)**: Praktikkan menambah mahasiswa baru, tunjukkan validasi saat kolom kosong atau format email salah, serta pencegahan saat memasukkan NIM yang sudah ada.
   - **Read (`mahasiswa.php`)**: Praktikkan fitur pencarian (misal mencari nama "Ahmad" atau NIM tertentu), filter jurusan, dan navigasi halaman (pagination).
   - **Update (`edit.php`)**: Praktikkan mengedit nama atau program studi salah satu mahasiswa dan tunjukkan perubahannya langsung terupdate di tabel.
   - **Delete (`hapus.php`)**: Praktikkan menghapus salah satu data mahasiswa, tunjukkan adanya modal dialog konfirmasi demi keamanan data pengguna.

5. **Keamanan Kode**:
   - Tekankan bahwa query SQL tidak menggabungkan string mentah secara langsung (*string concatenation*), melainkan menggunakan **Prepared Statements** (`prepare`, `bind_param`, `execute`) untuk menjamin keamanan dari celah SQL Injection.

