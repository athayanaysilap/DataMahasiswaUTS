Folder assets untuk menyimpan gambar atau ikon tambahan jika diperlukan di masa depan.
Ikon utama sistem saat ini telah terintegrasi secara profesional menggunakan Font Awesome 6 CDN.

