<?php


require_once 'koneksi.php';

$page_title = "Dashboard";
$breadcrumb = "Dashboard";
$include_chart = true; // Load Chart.js di footer

// 1. Ambil Total Mahasiswa
$query_total = "SELECT COUNT(*) AS total FROM mahasiswa";
$res_total = mysqli_query($koneksi, $query_total);
$total_mhs = ($res_total) ? mysqli_fetch_assoc($res_total)['total'] : 0;

// 2. Ambil Total Jurusan Terdaftar
$query_jurusan = "SELECT COUNT(DISTINCT jurusan) AS total_jurusan FROM mahasiswa";
$res_jurusan = mysqli_query($koneksi, $query_jurusan);
$total_jurusan = ($res_jurusan) ? mysqli_fetch_assoc($res_jurusan)['total_jurusan'] : 0;

// 3. Ambil Data Mahasiswa Paling Terakhir Ditambahkan
$query_terbaru = "SELECT nama, nim, created_at FROM mahasiswa ORDER BY id DESC LIMIT 1";
$res_terbaru = mysqli_query($koneksi, $query_terbaru);
$mhs_terbaru = ($res_terbaru && mysqli_num_rows($res_terbaru) > 0) ? mysqli_fetch_assoc($res_terbaru) : null;

// 4. Ambil Distribusi Mahasiswa per Jurusan (Untuk Chart.js)
$query_chart = "SELECT jurusan, COUNT(*) as jumlah FROM mahasiswa GROUP BY jurusan ORDER BY jumlah DESC";
$res_chart = mysqli_query($koneksi, $query_chart);

$chart_labels = [];
$chart_data = [];
if ($res_chart) {
    while ($row_chart = mysqli_fetch_assoc($res_chart)) {
        $chart_labels[] = $row_chart['jurusan'];
        $chart_data[] = (int) $row_chart['jumlah'];
    }
}

// 5. Ambil 5 Mahasiswa Terbaru untuk Tabel Ringkasan
$query_list_terbaru = "SELECT * FROM mahasiswa ORDER BY id DESC LIMIT 5";
$res_list_terbaru = mysqli_query($koneksi, $query_list_terbaru);

// Catatan: Fungsi getJurusanBadgeClass() telah disediakan secara terpusat di koneksi.php

// Panggil Header
include_once 'includes/header.php';
?>

<!-- Welcome Banner -->
<div class="welcome-banner">
    <div class="banner-text">
        <h2>Selamat Datang, Administrator! 👋</h2>
        <p>Kelola data akademik mahasiswa secara efisien, rapi, dan terintegrasi melalui portal <strong>BlueStudent</strong>. Pantau statistik dan perbarui data dengan cepat.</p>
        <div class="banner-badge-group">
            <span class="banner-badge"><i class="fa-solid fa-shield-halved"></i> Sistem Aman & Terverifikasi</span>
            <span class="banner-badge"><i class="fa-solid fa-server"></i> Server Laragon Localhost</span>
            <span class="banner-badge"><i class="fa-solid fa-database"></i> Database: db_mahasiswa</span>
        </div>
    </div>
    <div class="banner-action">
        <a href="tambah.php" class="btn-banner">
            <i class="fa-solid fa-user-plus"></i> Tambah Mahasiswa
        </a>
    </div>
</div>

<!-- Statistik Cards Grid -->
<div class="stats-grid">
    <!-- Card 1: Total Mahasiswa -->
    <div class="stat-card">
        <div class="stat-icon-wrapper stat-icon-blue">
            <i class="fa-solid fa-user-graduate"></i>
        </div>
        <div class="stat-info">
            <div class="stat-title">Total Mahasiswa</div>
            <div class="stat-value"><?= number_format($total_mhs, 0, ',', '.') ?></div>
            <div class="stat-subtext">
                <span class="highlight"><i class="fa-solid fa-circle-check"></i> Aktif</span> di database
            </div>
        </div>
    </div>

    <!-- Card 2: Total Jurusan -->
    <div class="stat-card">
        <div class="stat-icon-wrapper stat-icon-navy">
            <i class="fa-solid fa-graduation-cap"></i>
        </div>
        <div class="stat-info">
            <div class="stat-title">Program Studi / Jurusan</div>
            <div class="stat-value"><?= $total_jurusan ?></div>
            <div class="stat-subtext">
                <span>Tersebar di berbagai fakultas</span>
            </div>
        </div>
    </div>

    <!-- Card 3: Mahasiswa Terbaru -->
    <div class="stat-card">
        <div class="stat-icon-wrapper stat-icon-sky">
            <i class="fa-solid fa-sparkles"></i>
        </div>
        <div class="stat-info">
            <div class="stat-title">Data Baru Ditambahkan</div>
            <div class="stat-value" style="font-size: 16px; font-weight: 700; text-overflow: ellipsis; overflow: hidden; white-space: nowrap;">
                <?= $mhs_terbaru ? htmlspecialchars($mhs_terbaru['nama']) : 'Belum Ada' ?>
            </div>
            <div class="stat-subtext">
                <span>NIM: <?= $mhs_terbaru ? htmlspecialchars($mhs_terbaru['nim']) : '-' ?></span>
            </div>
        </div>
    </div>

    <!-- Card 4: Status Database & Server -->
    <div class="stat-card">
        <div class="stat-icon-wrapper stat-icon-green">
            <i class="fa-solid fa-database"></i>
        </div>
        <div class="stat-info">
            <div class="stat-title">Status Database</div>
            <div class="stat-value" style="font-size: 19px; color: #10B981;">Online</div>
            <div class="stat-subtext">
                <span>MySQL Connected via Laragon</span>
            </div>
        </div>
    </div>
</div>

<!-- Grid Konten Dashboard: Tabel Mahasiswa Terbaru & Grafik -->
<div class="dashboard-grid">
    <!-- Kolom Kiri: Tabel Terbaru & Grafik Distribusi Jurusan -->
    <div class="dashboard-left">
        <!-- Card: Mahasiswa Terbaru -->
        <div class="card">
            <div class="card-header">
                <div class="card-title-group">
                    <div class="card-header-icon">
                        <i class="fa-solid fa-clock-rotate-left"></i>
                    </div>
                    <div>
                        <h3 class="card-title">Mahasiswa Terbaru</h3>
                        <p class="card-subtitle">5 mahasiswa yang paling akhir ditambahkan ke dalam sistem</p>
                    </div>
                </div>
                <a href="mahasiswa.php" class="btn btn-outline-primary btn-sm">
                    Lihat Semua <i class="fa-solid fa-arrow-right"></i>
                </a>
            </div>
            <div class="card-body" style="padding: 0;">
                <div class="table-responsive">
                    <table class="custom-table table-zebra">
                        <thead>
                            <tr>
                                <th>NIM</th>
                                <th>Nama Mahasiswa</th>
                                <th>Jurusan</th>
                                <th>Email</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($res_list_terbaru && mysqli_num_rows($res_list_terbaru) > 0): ?>
                                <?php while ($mhs = mysqli_fetch_assoc($res_list_terbaru)): ?>
                                    <tr>
                                        <td>
                                            <span class="nim-badge"><?= htmlspecialchars($mhs['nim']) ?></span>
                                        </td>
                                        <td>
                                            <strong><?= htmlspecialchars($mhs['nama']) ?></strong>
                                        </td>
                                        <td>
                                            <span class="jurusan-badge <?= getJurusanBadgeClass($mhs['jurusan']) ?>">
                                                <i class="fa-solid fa-bookmark" style="font-size: 10px;"></i>
                                                <?= htmlspecialchars($mhs['jurusan']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="email-link">
                                                <i class="fa-regular fa-envelope"></i>
                                                <?= htmlspecialchars($mhs['email']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="action-group">
                                                <a href="edit.php?id=<?= $mhs['id'] ?>" class="btn-action btn-action-edit" title="Edit Data">
                                                    <i class="fa-solid fa-pen-to-square"></i>
                                                </a>
                                                <button type="button" class="btn-action btn-action-delete" 
                                                        data-id="<?= $mhs['id'] ?>" 
                                                        data-nama="<?= htmlspecialchars($mhs['nama']) ?>" 
                                                        title="Hapus Data">
                                                    <i class="fa-solid fa-trash-can"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5">
                                        <div class="empty-state">
                                            <div class="empty-state-icon">
                                                <i class="fa-solid fa-folder-open"></i>
                                            </div>
                                            <div class="empty-state-title">Belum Ada Data Mahasiswa</div>
                                            <p class="empty-state-desc">Tambahkan data mahasiswa baru untuk mulai mengelola sistem akademik ini.</p>
                                            <a href="tambah.php" class="btn btn-primary btn-sm">
                                                <i class="fa-solid fa-plus"></i> Tambah Mahasiswa Sekarang
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Card: Visualisasi Grafik Jurusan -->
        <div class="card">
            <div class="card-header">
                <div class="card-title-group">
                    <div class="card-header-icon">
                        <i class="fa-solid fa-chart-column"></i>
                    </div>
                    <div>
                        <h3 class="card-title">Distribusi Mahasiswa per Jurusan</h3>
                        <p class="card-subtitle">Grafik perbandingan jumlah mahasiswa aktif berdasarkan program studi</p>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div style="position: relative; height: 260px; width: 100%;">
                    <canvas id="jurusanChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Kolom Kanan: Aksi Cepat & Info Sistem -->
    <div class="dashboard-right">
        <!-- Card: Aksi Cepat -->
        <div class="card">
            <div class="card-header">
                <div class="card-title-group">
                    <div class="card-header-icon">
                        <i class="fa-solid fa-bolt"></i>
                    </div>
                    <div>
                        <h3 class="card-title">Aksi Cepat</h3>
                        <p class="card-subtitle">Pintasan fitur utama</p>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div style="display: flex; flex-direction: column; gap: 12px;">
                    <a href="tambah.php" class="btn btn-primary" style="justify-content: flex-start; padding: 12px 18px;">
                        <i class="fa-solid fa-user-plus"></i> Tambah Mahasiswa Baru
                    </a>
                    <a href="mahasiswa.php" class="btn btn-outline-primary" style="justify-content: flex-start; padding: 12px 18px;">
                        <i class="fa-solid fa-table-list"></i> Kelola & Cari Mahasiswa
                    </a>
                    <a href="pengaturan.php" class="btn btn-secondary" style="justify-content: flex-start; padding: 12px 18px;">
                        <i class="fa-solid fa-gear"></i> Informasi Sistem & Proyek
                    </a>
                </div>
            </div>
        </div>

        <!-- Card: Status Lingkungan Pengembangan -->
        <div class="card">
            <div class="card-header">
                <div class="card-title-group">
                    <div class="card-header-icon">
                        <i class="fa-solid fa-circle-info"></i>
                    </div>
                    <div>
                        <h3 class="card-title">Lingkungan Sistem</h3>
                        <p class="card-subtitle">Detail server Laragon</p>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <table class="info-table">
                    <tr>
                        <td class="label-col">Web Server</td>
                        <td class="val-col"><span class="badge-tech">Apache / Laragon</span></td>
                    </tr>
                    <tr>
                        <td class="label-col">Versi PHP</td>
                        <td class="val-col"><span class="badge-tech">PHP <?= phpversion() ?></span></td>
                    </tr>
                    <tr>
                        <td class="label-col">Database</td>
                        <td class="val-col"><span class="badge-tech">MySQL (InnoDB)</span></td>
                    </tr>
                    <tr>
                        <td class="label-col">Nama DB</td>
                        <td class="val-col"><code>db_mahasiswa</code></td>
                    </tr>
                    <tr>
                        <td class="label-col">Tabel Utama</td>
                        <td class="val-col"><code>mahasiswa</code></td>
                    </tr>
                    <tr>
                        <td class="label-col">Metode Query</td>
                        <td class="val-col"><span class="badge-tech">Prepared Statements</span></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Script Render Grafik Chart.js -->
<script>
document.addEventListener('DOMContentLoaded', function () {
    const ctx = document.getElementById('jurusanChart');
    if (!ctx) return;

    const labels = <?= json_encode($chart_labels) ?>;
    const dataValues = <?= json_encode($chart_data) ?>;

    // Palette gradient biru
    const backgroundColors = [
        'rgba(37, 99, 235, 0.85)',
        'rgba(59, 130, 246, 0.85)',
        'rgba(96, 165, 250, 0.85)',
        'rgba(125, 211, 252, 0.85)',
        'rgba(30, 64, 175, 0.85)',
        'rgba(14, 116, 144, 0.85)'
    ];

    const borderColors = [
        '#1D4ED8',
        '#2563EB',
        '#3B82F6',
        '#60A5FA',
        '#1E40AF',
        '#0E7490'
    ];

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Jumlah Mahasiswa',
                data: dataValues,
                backgroundColor: backgroundColors,
                borderColor: borderColors,
                borderWidth: 1.5,
                borderRadius: 8,
                barThickness: 36
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: '#0B1F4D',
                    titleColor: '#FFFFFF',
                    bodyColor: '#7DD3FC',
                    padding: 12,
                    cornerRadius: 8,
                    callbacks: {
                        label: function (context) {
                            return ` ${context.parsed.y} Mahasiswa`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1,
                        font: { family: "'Plus Jakarta Sans', sans-serif", size: 12 },
                        color: '#64748B'
                    },
                    grid: {
                        color: '#F1F5F9'
                    }
                },
                x: {
                    ticks: {
                        font: { family: "'Plus Jakarta Sans', sans-serif", size: 11.5, weight: '500' },
                        color: '#334155'
                    },
                    grid: {
                        display: false
                    }
                }
            }
        }
    });
});
</script>

<?php
include_once 'includes/footer.php';
?>
