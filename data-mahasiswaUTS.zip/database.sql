
CREATE DATABASE IF NOT EXISTS db_mahasiswa
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE db_mahasiswa;

CREATE TABLE IF NOT EXISTS mahasiswa (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nim VARCHAR(20) NOT NULL UNIQUE,
    nama VARCHAR(100) NOT NULL,
    jurusan VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;

INSERT INTO mahasiswa (nim, nama, jurusan, email)
VALUES
('2301010001', 'Ahmad Fadillah', 'Teknik Informatika', 'ahmad.fadillah@student.ac.id'),
('2301010002', 'Siti Nur Aisyah', 'Sistem Informasi', 'siti.aisyah@student.ac.id'),
('2301010003', 'Budi Santoso', 'Teknik Informatika', 'budi.santoso@student.ac.id'),
('2301010004', 'Putri Ayu Lestari', 'Sains Data', 'putri.ayu@student.ac.id'),
('2301010005', 'Dimas Arya Pratama', 'Teknik Komputer', 'dimas.arya@student.ac.id'),
('2301010006', 'Dewi Anggraini', 'Manajemen Informatika', 'dewi.anggraini@student.ac.id'),
('2301010007', 'Rizky Ramadhan', 'Rekayasa Perangkat Lunak', 'rizky.ramadhan@student.ac.id'),
('2301010008', 'Nabila Zahra', 'Teknik Informatika', 'nabila.zahra@student.ac.id'),
('2301010009', 'Farhan Maulana', 'Sistem Informasi', 'farhan.maulana@student.ac.id'),
('2301010010', 'Clarissa Amanda', 'Rekayasa Perangkat Lunak', 'clarissa.amanda@student.ac.id');
