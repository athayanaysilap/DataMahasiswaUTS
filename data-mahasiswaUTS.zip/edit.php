<?php
/**
 * ========================================================
 * File: edit.php
 * Deskripsi: Halaman Edit / Perbarui Data Mahasiswa (Update)
 *            Mengambil data berdasar ID, validasi input,
 *            cek duplikasi NIM terhadap record lain, dan
 *            Prepared Statements UPDATE.
 * Aplikasi: BlueStudent - Sistem Manajemen Data Mahasiswa
 * ========================================================
 */

require_once 'koneksi.php';

$page_title = "Edit Mahasiswa";
$breadcrumb = "Edit Mahasiswa";

// 1. Validasi parameter ID
if (!isset($_GET['id']) || empty($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: mahasiswa.php?status=gagal&pesan=ID+mahasiswa+tidak+valid");
    exit;
}

$id = (int) $_GET['id'];
$errors = [];

// 2. Ambil data mahasiswa yang sedang diedit menggunakan Prepared Statement
$query_get = "SELECT * FROM mahasiswa WHERE id = ? LIMIT 1";
$stmt_get = mysqli_prepare($koneksi, $query_get);
mysqli_stmt_bind_param($stmt_get, "i", $id);
mysqli_stmt_execute($stmt_get);
$result_get = mysqli_stmt_get_result($stmt_get);

if (!$result_get || mysqli_num_rows($result_get) === 0) {
    header("Location: mahasiswa.php?status=gagal&pesan=Data+mahasiswa+tidak+ditemukan+di+database");
    exit;
}

$mhs = mysqli_fetch_assoc($result_get);
mysqli_stmt_close($stmt_get);

// Inisialisasi nilai form awal dari data database
$nim     = $mhs['nim'];
$nama    = $mhs['nama'];
$jurusan = $mhs['jurusan'];
$email   = $mhs['email'];

// 3. Proses Update saat metode POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil dan bersihkan data input
    $nim     = cleanInput($_POST['nim'] ?? '');
    $nama    = cleanInput($_POST['nama'] ?? '');
    $jurusan = cleanInput($_POST['jurusan'] ?? '');
    $email   = cleanInput($_POST['email'] ?? '');

    // Validasi Server-Side
    if (empty($nim)) {
        $errors[] = "NIM mahasiswa tidak boleh kosong.";
    } elseif (!preg_match('/^[0-9a-zA-Z\.\-_]{4,20}$/', $nim)) {
        $errors[] = "Format NIM tidak valid (hanya huruf, angka, 4-20 karakter).";
    }

    if (empty($nama)) {
        $errors[] = "Nama lengkap mahasiswa tidak boleh kosong.";
    } elseif (strlen($nama) < 3) {
        $errors[] = "Nama mahasiswa minimal 3 karakter.";
    }

    if (empty($jurusan)) {
        $errors[] = "Program studi / jurusan wajib dipilih.";
    }

    if (empty($email)) {
        $errors[] = "Alamat email mahasiswa tidak boleh kosong.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Format penulisan email tidak valid.";
    }

    // Cek apakah NIM yang dimasukkan sudah dipakai oleh mahasiswa LAIN
    if (empty($errors)) {
        $check_sql = "SELECT id FROM mahasiswa WHERE nim = ? AND id != ? LIMIT 1";
        $stmt_check = mysqli_prepare($koneksi, $check_sql);
        mysqli_stmt_bind_param($stmt_check, "si", $nim, $id);
        mysqli_stmt_execute($stmt_check);
        mysqli_stmt_store_result($stmt_check);

        if (mysqli_stmt_num_rows($stmt_check) > 0) {
            $errors[] = "NIM <strong>" . htmlspecialchars($nim) . "</strong> sudah digunakan oleh mahasiswa lain. Silakan gunakan NIM yang berbeda.";
        }
        mysqli_stmt_close($stmt_check);
    }

    // Jika lolos validasi, lakukan UPDATE dengan Prepared Statement
    if (empty($errors)) {
        $update_sql = "UPDATE mahasiswa SET nim = ?, nama = ?, jurusan = ?, email = ? WHERE id = ?";
        $stmt_update = mysqli_prepare($koneksi, $update_sql);

        if ($stmt_update) {
            mysqli_stmt_bind_param($stmt_update, "ssssi", $nim, $nama, $jurusan, $email, $id);

            if (mysqli_stmt_execute($stmt_update)) {
                mysqli_stmt_close($stmt_update);
                header("Location: mahasiswa.php?status=sukses_edit");
                exit;
            } else {
                $errors[] = "Gagal memperbarui data: " . mysqli_error($koneksi);
            }
            mysqli_stmt_close($stmt_update);
        } else {
            $errors[] = "Terjadi kegagalan pada prepared statement sistem.";
        }
    }
}

// Daftar Jurusan
$daftar_jurusan = [
    'Teknik Informatika',
    'Sistem Informasi',
    'Teknik Komputer',
    'Manajemen Informatika',
    'Rekayasa Perangkat Lunak',
    'Sains Data',
    'Teknologi Informasi',
    'Ilmu Komunikasi'
];

include_once 'includes/header.php';
?>

<div style="max-width: 780px; margin: 0 auto;">
    <!-- Alert Jika Ada Pesan Kesalahan Validasi -->
    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger" role="alert">
            <div class="alert-content">
                <i class="fa-solid fa-triangle-exclamation alert-icon"></i>
                <div>
                    <strong>Perhatian!</strong> Harap perbaiki beberapa isian berikut:
                    <ul style="margin: 6px 0 0 18px; list-style-type: disc;">
                        <?php foreach ($errors as $error): ?>
                            <li><?= $error ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
            <button type="button" class="alert-close" aria-label="Tutup notifikasi">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
    <?php endif; ?>

    <!-- Card Form Edit Mahasiswa -->
    <div class="card">
        <div class="card-header" style="background: linear-gradient(135deg, #F8FAFC 0%, #EFF6FF 100%);">
            <div class="card-title-group">
                <div class="card-header-icon" style="background: #1D4ED8; color: #FFFFFF;">
                    <i class="fa-solid fa-pen-to-square"></i>
                </div>
                <div>
                    <h3 class="card-title">Edit Data Mahasiswa</h3>
                    <p class="card-subtitle">Perbarui informasi mahasiswa (ID: #<?= $id ?>)</p>
                </div>
            </div>
            <a href="mahasiswa.php" class="btn btn-secondary btn-sm">
                <i class="fa-solid fa-arrow-left"></i> Kembali ke Daftar
            </a>
        </div>

        <div class="card-body" style="padding: 32px 36px;">
            <form action="edit.php?id=<?= $id ?>" method="POST" novalidate>
                <!-- Field NIM -->
                <div class="form-group">
                    <label for="nim" class="form-label">
                        Nomor Induk Mahasiswa (NIM) <span class="required">*</span>
                    </label>
                    <input type="text" id="nim" name="nim" class="form-control" 
                           value="<?= htmlspecialchars($nim) ?>" 
                           maxlength="20" required>
                    <div class="form-help">
                        <i class="fa-solid fa-circle-info"></i> NIM unik sebagai identitas mahasiswa di universitas.
                    </div>
                </div>

                <!-- Field Nama Lengkap -->
                <div class="form-group">
                    <label for="nama" class="form-label">
                        Nama Lengkap Mahasiswa <span class="required">*</span>
                    </label>
                    <input type="text" id="nama" name="nama" class="form-control" 
                           value="<?= htmlspecialchars($nama) ?>" 
                           maxlength="100" required>
                    <div class="form-help">
                        <i class="fa-solid fa-circle-info"></i> Periksa kembali ejaan nama sesuai KTP / KTM.
                    </div>
                </div>

                <!-- Field Jurusan -->
                <div class="form-group">
                    <label for="jurusan" class="form-label">
                        Program Studi / Jurusan <span class="required">*</span>
                    </label>
                    <select id="jurusan" name="jurusan" class="form-control" required>
                        <option value="">-- Pilih Program Studi --</option>
                        <?php foreach ($daftar_jurusan as $jrs): ?>
                            <option value="<?= htmlspecialchars($jrs) ?>" <?= ($jurusan === $jrs) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($jrs) ?>
                            </option>
                        <?php endforeach; ?>
                        <!-- Jika ada jurusan khusus yang tidak ada di daftar default -->
                        <?php if (!in_array($jurusan, $daftar_jurusan) && !empty($jurusan)): ?>
                            <option value="<?= htmlspecialchars($jurusan) ?>" selected>
                                <?= htmlspecialchars($jurusan) ?>
                            </option>
                        <?php endif; ?>
                    </select>
                    <div class="form-help">
                        <i class="fa-solid fa-circle-info"></i> Program studi mahasiswa yang terdaftar saat ini.
                    </div>
                </div>

                <!-- Field Email -->
                <div class="form-group">
                    <label for="email" class="form-label">
                        Alamat Email Mahasiswa <span class="required">*</span>
                    </label>
                    <input type="email" id="email" name="email" class="form-control" 
                           value="<?= htmlspecialchars($email) ?>" 
                           maxlength="100" required>
                    <div class="form-help">
                        <i class="fa-solid fa-circle-info"></i> Email aktif untuk korespondensi akademik.
                    </div>
                </div>

                <!-- Tombol Aksi Simpan Perubahan & Batal -->
                <div class="form-actions">
                    <a href="mahasiswa.php" class="btn btn-secondary">
                        <i class="fa-solid fa-xmark"></i> Batal
                    </a>
                    <button type="submit" class="btn btn-primary" style="min-width: 170px;">
                        <i class="fa-solid fa-arrows-rotate"></i> Perbarui Perubahan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
include_once 'includes/footer.php';
?>

