<?php
/**
 * ========================================================
 * File: hapus.php
 * Deskripsi: Skrip Pemrosesan Hapus Data Mahasiswa (Delete)
 *            Menerima parameter ID melalui GET, validasi ID,
 *            dan menjalankan query Prepared Statement DELETE.
 * Aplikasi: BlueStudent - Sistem Manajemen Data Mahasiswa
 * ========================================================
 */

require_once 'koneksi.php';

// 1. Validasi parameter ID
if (!isset($_GET['id']) || empty($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: mahasiswa.php?status=gagal&pesan=ID+mahasiswa+tidak+valid");
    exit;
}

$id = (int) $_GET['id'];

// 2. Pastikan data mahasiswa memang ada di database sebelum dihapus
$check_sql = "SELECT id, nama FROM mahasiswa WHERE id = ? LIMIT 1";
$stmt_check = mysqli_prepare($koneksi, $check_sql);
mysqli_stmt_bind_param($stmt_check, "i", $id);
mysqli_stmt_execute($stmt_check);
$result_check = mysqli_stmt_get_result($stmt_check);

if (!$result_check || mysqli_num_rows($result_check) === 0) {
    mysqli_stmt_close($stmt_check);
    header("Location: mahasiswa.php?status=gagal&pesan=Data+mahasiswa+tidak+ditemukan");
    exit;
}

$data_mhs = mysqli_fetch_assoc($result_check);
mysqli_stmt_close($stmt_check);

// 3. Eksekusi Penghapusan Data dengan Prepared Statement
$delete_sql = "DELETE FROM mahasiswa WHERE id = ?";
$stmt_delete = mysqli_prepare($koneksi, $delete_sql);

if ($stmt_delete) {
    mysqli_stmt_bind_param($stmt_delete, "i", $id);
    
    if (mysqli_stmt_execute($stmt_delete)) {
        mysqli_stmt_close($stmt_delete);
        // Berhasil dihapus, arahkan kembali dengan notifikasi sukses
        header("Location: mahasiswa.php?status=sukses_hapus");
        exit;
    } else {
        $error_msg = urlencode("Gagal menghapus data: " . mysqli_error($koneksi));
        mysqli_stmt_close($stmt_delete);
        header("Location: mahasiswa.php?status=gagal&pesan=" . $error_msg);
        exit;
    }
} else {
    header("Location: mahasiswa.php?status=gagal&pesan=Terjadi+kesalahan+pada+prepared+statement");
    exit;
}
?>

