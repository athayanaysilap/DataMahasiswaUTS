        </div><!-- End of .content-wrapper -->
    </main><!-- End of .main-content -->
</div><!-- End of .app-container -->

<!-- Modal Konfirmasi Hapus Data Mahasiswa -->
<div class="modal-overlay" id="deleteModal" role="dialog" aria-modal="true" aria-labelledby="modalTitle">
    <div class="modal-dialog">
        <div class="modal-icon-danger">
            <i class="fa-solid fa-triangle-exclamation"></i>
        </div>
        <h3 class="modal-title" id="modalTitle">Konfirmasi Hapus Data</h3>
        <p class="modal-text">
            Apakah Anda yakin ingin menghapus data mahasiswa <br>
            <span class="modal-student-name" id="modalStudentName">...</span>?<br>
            <small style="color: #EF4444; display: block; margin-top: 6px;">Tindakan ini permanen dan data tidak dapat dikembalikan.</small>
        </p>
        <div class="modal-actions">
            <button type="button" class="btn btn-secondary" id="cancelDeleteBtn">
                <i class="fa-solid fa-xmark"></i> Batal
            </button>
            <a href="#" class="btn btn-primary" id="confirmDeleteBtn" style="background: linear-gradient(135deg, #DC2626 0%, #EF4444 100%); border: none;">
                <i class="fa-solid fa-trash"></i> Ya, Hapus
            </a>
        </div>
    </div>
</div>

<?php if (isset($include_chart) && $include_chart === true): ?>
<!-- Chart.js CDN untuk Visualisasi Statistik -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<?php endif; ?>

<!-- Script Utama Interaksi UI -->
<script src="script.js"></script>

</body>
</html>

