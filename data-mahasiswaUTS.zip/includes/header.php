<?php
/**
 * ========================================================
 * File: includes/header.php
 * Deskripsi: Template Header dan Top Bar Navigasi
 * Aplikasi: BlueStudent - Sistem Manajemen Data Mahasiswa
 * ========================================================
 */

// Array nama hari dan bulan dalam Bahasa Indonesia
$hari_indonesia = [
    'Sunday' => 'Minggu', 'Monday' => 'Senin', 'Tuesday' => 'Selasa',
    'Wednesday' => 'Rabu', 'Thursday' => 'Kamis', 'Friday' => 'Jumat', 'Saturday' => 'Sabtu'
];
$bulan_indonesia = [
    '01' => 'Januari', '02' => 'Februari', '03' => 'Maret', '04' => 'April',
    '05' => 'Mei', '06' => 'Juni', '07' => 'Juli', '08' => 'Agustus',
    '09' => 'September', '10' => 'Oktober', '11' => 'November', '12' => 'Desember'
];

$hari_ini = $hari_indonesia[date('l')];
$tgl = date('d');
$bln = $bulan_indonesia[date('m')];
$thn = date('Y');
$tanggal_formatted = "$hari_ini, $tgl $bln $thn";
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($page_title) ? htmlspecialchars($page_title) . ' - BlueStudent' : 'BlueStudent - Sistem Data Mahasiswa' ?></title>
    
    <!-- Google Fonts: Plus Jakarta Sans & Poppins -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Font Awesome 6 Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    <!-- Custom CSS Modern Blue Gradient Theme -->
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="app-container">
    <!-- Panggil Komponen Sidebar -->
    <?php include_once __DIR__ . '/sidebar.php'; ?>

    <!-- Area Konten Utama -->
    <main class="main-content">
        <!-- Top Header Navigation -->
        <header class="top-header">
            <div class="header-left">
                <!-- Tombol Toggle Sidebar Mobile -->
                <button type="button" class="sidebar-toggle-btn" aria-label="Toggle Navigation">
                    <i class="fa-solid fa-bars-staggered"></i>
                </button>

                <!-- Breadcrumb Navigasi -->
                <nav class="breadcrumb-box" aria-label="Breadcrumb">
                    <a href="dashboard.php"><i class="fa-solid fa-house-chimney"></i> Home</a>
                    <span class="breadcrumb-separator"><i class="fa-solid fa-chevron-right"></i></span>
                    <span class="breadcrumb-current"><?= isset($breadcrumb) ? htmlspecialchars($breadcrumb) : 'Dashboard' ?></span>
                </nav>
            </div>

            <div class="header-right">
                <!-- Tanggal Dinamis -->
                <div class="header-date-badge">
                    <i class="fa-regular fa-calendar-days"></i>
                    <span><?= $tanggal_formatted ?></span>
                </div>

                <!-- Profil Administrator -->
                <div class="header-admin-pill">
                    <div class="admin-pill-text">
                        <div class="admin-pill-name">Administrator</div>
                        <div class="admin-pill-status"><i class="fa-solid fa-circle" style="font-size: 8px;"></i> Online</div>
                    </div>
                    <div class="admin-avatar-sm">
                        <i class="fa-solid fa-user-tie"></i>
                    </div>
                </div>
            </div>
        </header>

        <!-- Wrapper Konten Halaman -->
        <div class="content-wrapper">

