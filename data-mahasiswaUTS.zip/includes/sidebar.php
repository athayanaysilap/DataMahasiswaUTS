<?php
/**
 * ========================================================
 * File: includes/sidebar.php
 * Deskripsi: Template Sidebar Navigasi BlueStudent
 * Aplikasi: BlueStudent - Sistem Manajemen Data Mahasiswa
 * ========================================================
 */
$current_page = basename($_SERVER['PHP_SELF']);
?>
<aside class="sidebar">
    <!-- Brand / Logo Aplikasi -->
    <div class="sidebar-brand">
        <div class="brand-icon">
            <i class="fa-solid fa-graduation-cap"></i>
        </div>
        <div class="brand-text">
            <h1>BlueStudent</h1>
            <span>Academic Portal</span>
        </div>
    </div>

    <!-- Menu Navigasi Utama -->
    <nav class="sidebar-menu">
        <div class="menu-label">Menu Utama</div>
        <ul>
            <li class="nav-item">
                <a href="dashboard.php" class="nav-link <?= ($current_page == 'dashboard.php' || $current_page == 'index.php') ? 'active' : '' ?>">
                    <i class="fa-solid fa-chart-pie"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="mahasiswa.php" class="nav-link <?= ($current_page == 'mahasiswa.php') ? 'active' : '' ?>">
                    <i class="fa-solid fa-user-graduate"></i>
                    <span>Data Mahasiswa</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="tambah.php" class="nav-link <?= ($current_page == 'tambah.php') ? 'active' : '' ?>">
                    <i class="fa-solid fa-user-plus"></i>
                    <span>Tambah Mahasiswa</span>
                </a>
            </li>
        </ul>

        <div class="menu-label" style="margin-top: 24px;">Sistem & Konfigurasi</div>
        <ul>
            <li class="nav-item">
                <a href="pengaturan.php" class="nav-link <?= ($current_page == 'pengaturan.php') ? 'active' : '' ?>">
                    <i class="fa-solid fa-sliders"></i>
                    <span>Pengaturan</span>
                </a>
            </li>
        </ul>
    </nav>

    <!-- Sidebar Footer / Info Pengguna & Logout -->
    <div class="sidebar-footer">
        <div class="user-snippet">
            <div class="user-avatar-sm">
                AD
            </div>
            <div class="user-meta">
                <div class="user-name">Administrator</div>
                <div class="user-role">Super Admin</div>
            </div>
            <a href="logout.php" class="btn-logout-icon" title="Keluar dari Sistem" onclick="return confirm('Apakah Anda yakin ingin logout?');">
                <i class="fa-solid fa-arrow-right-from-bracket"></i>
            </a>
        </div>
    </div>
</aside>

