<?php
/**
 * ========================================================
 * File: index.php
 * Deskripsi: Entry point utama aplikasi BlueStudent.
 *            Otomatis mengarahkan pengguna ke halaman Dashboard.
 * Aplikasi: BlueStudent - Sistem Manajemen Data Mahasiswa
 * ========================================================
 */

// Arahkan ke dashboard
header("Location: dashboard.php");
exit;
?>

