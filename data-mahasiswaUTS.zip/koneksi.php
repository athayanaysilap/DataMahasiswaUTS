
<?php
/**
 * File: koneksi.php
 * Aplikasi: BlueStudent - Data Mahasiswa
 */

// Konfigurasi database
$host = "localhost";
$user = "root";
$pass = "";
$db   = "db_mahasiswa";

// Hubungkan ke server MySQL
$koneksi = mysqli_connect($host, $user, $pass);

if (!$koneksi) {
    die("Koneksi MySQL gagal: " . mysqli_connect_error());
}

// Buat database jika belum tersedia
$sqlDatabase = "CREATE DATABASE IF NOT EXISTS `$db`
                CHARACTER SET utf8mb4
                COLLATE utf8mb4_unicode_ci";

if (!mysqli_query($koneksi, $sqlDatabase)) {
    die("Gagal membuat database: " . mysqli_error($koneksi));
}

// Pilih database
if (!mysqli_select_db($koneksi, $db)) {
    die("Gagal memilih database: " . mysqli_error($koneksi));
}

// Atur encoding
mysqli_set_charset($koneksi, "utf8mb4");

// Buat tabel mahasiswa jika belum tersedia
$sqlTabel = "CREATE TABLE IF NOT EXISTS mahasiswa (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nim VARCHAR(20) NOT NULL UNIQUE,
    nama VARCHAR(100) NOT NULL,
    jurusan VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci";

if (!mysqli_query($koneksi, $sqlTabel)) {
    die("Gagal membuat tabel: " . mysqli_error($koneksi));
}

// Fungsi membersihkan output HTML
if (!function_exists('cleanInput')) {
    function cleanInput($data) {
        return htmlspecialchars(
            trim((string) $data),
            ENT_QUOTES,
            'UTF-8'
        );
    }
}

// Fungsi menentukan warna badge jurusan
if (!function_exists('getJurusanBadgeClass')) {
    function getJurusanBadgeClass($jurusan) {
        switch (strtolower(trim($jurusan))) {
            case 'teknik informatika':
                return 'jurusan-ti';

            case 'sistem informasi':
                return 'jurusan-si';

            case 'teknik komputer':
                return 'jurusan-tk';

            case 'manajemen informatika':
                return 'jurusan-mi';

            case 'rekayasa perangkat lunak':
                return 'jurusan-rpl';

            case 'sains data':
                return 'jurusan-sd';

            default:
                return 'jurusan-default';
        }
    }
}
?>
