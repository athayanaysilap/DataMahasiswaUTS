<?php
/**
 * ========================================================
 * File: logout.php
 * Deskripsi: Halaman Logout / Selesai Sesi
 * Aplikasi: BlueStudent - Sistem Manajemen Data Mahasiswa
 * ========================================================
 */

// Mulai sesi jika belum ada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Bersihkan seluruh data sesi
$_SESSION = [];
session_unset();
session_destroy();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sesi Selesai - BlueStudent</title>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #0B1F4D 0%, #1D4ED8 50%, #3B82F6 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .logout-card {
            background: #FFFFFF;
            max-width: 440px;
            width: 100%;
            border-radius: 20px;
            padding: 40px 32px;
            text-align: center;
            box-shadow: 0 20px 45px rgba(11, 31, 77, 0.3);
            animation: fadeIn 0.4s ease-out;
        }

        .icon-circle {
            width: 72px;
            height: 72px;
            border-radius: 50%;
            background: #EFF6FF;
            color: #2563EB;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            margin-bottom: 20px;
            box-shadow: 0 8px 20px rgba(37, 99, 235, 0.15);
        }

        h2 {
            font-size: 22px;
            font-weight: 700;
            color: #0B1F4D;
            margin-bottom: 8px;
        }

        p {
            font-size: 13.5px;
            color: #64748B;
            line-height: 1.6;
            margin-bottom: 28px;
        }

        .btn-return {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            width: 100%;
            padding: 13px 20px;
            background: linear-gradient(135deg, #0B1F4D 0%, #1D4ED8 100%);
            color: #FFFFFF;
            text-decoration: none;
            border-radius: 12px;
            font-size: 14px;
            font-weight: 600;
            box-shadow: 0 4px 15px rgba(29, 78, 216, 0.3);
            transition: all 0.25s ease;
        }

        .btn-return:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(29, 78, 216, 0.45);
        }

        .app-badge {
            margin-top: 24px;
            font-size: 12px;
            color: #94A3B8;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(15px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>

<div class="logout-card">
    <div class="icon-circle">
        <i class="fa-solid fa-lock"></i>
    </div>
    <h2>Sesi Berhasil Diakhiri</h2>
    <p>
        Anda telah keluar dari sistem <strong>BlueStudent</strong>. Seluruh perubahan data mahasiswa telah tersimpan aman di basis data MySQL.
    </p>

    <a href="dashboard.php" class="btn-return">
        <i class="fa-solid fa-arrow-right-to-bracket"></i> Masuk Kembali ke Dashboard
    </a>

    <div class="app-badge">
        <i class="fa-solid fa-graduation-cap"></i> BlueStudent Academic Portal &bull; Laragon Localhost
    </div>
</div>

</body>
</html>

