<?php
/**
 * ========================================================
 * File: mahasiswa.php
 * Deskripsi: Halaman Kelola Data Mahasiswa (Read & Delete)
 *            Fitur: Pencarian (NIM/Nama), Filter Jurusan,
 *            Pagination, Tombol Aksi (Edit/Hapus), Flash Alert.
 * Aplikasi: BlueStudent - Sistem Manajemen Data Mahasiswa
 * ========================================================
 */

require_once 'koneksi.php';

$page_title = "Data Mahasiswa";
$breadcrumb = "Data Mahasiswa";

// Tangkap notifikasi pesan dari parameter URL
$alert_msg = "";
$alert_type = "";

if (isset($_GET['status'])) {
    if ($_GET['status'] == 'sukses_tambah') {
        $alert_type = "success";
        $alert_msg = "Data mahasiswa baru berhasil ditambahkan ke database!";
    } elseif ($_GET['status'] == 'sukses_edit') {
        $alert_type = "success";
        $alert_msg = "Perubahan data mahasiswa berhasil disimpan!";
    } elseif ($_GET['status'] == 'sukses_hapus') {
        $alert_type = "success";
        $alert_msg = "Data mahasiswa berhasil dihapus secara permanen!";
    } elseif ($_GET['status'] == 'gagal') {
        $alert_type = "danger";
        $alert_msg = isset($_GET['pesan']) ? cleanInput($_GET['pesan']) : "Terjadi kesalahan pada sistem. Silakan coba lagi.";
    }
}

// 1. Parameter Pencarian dan Filter
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$jurusan_filter = isset($_GET['jurusan']) ? trim($_GET['jurusan']) : '';

// 2. Konfigurasi Pagination
$limit = 7; // Jumlah data per halaman
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;
$offset = ($page - 1) * $limit;

// 3. Bangun Query Hitung Total Data (Menggunakan Prepared Statement)
$sql_count = "SELECT COUNT(*) as total FROM mahasiswa WHERE 1=1";
$params_count = [];
$types_count = "";

if ($search !== '') {
    $sql_count .= " AND (nim LIKE ? OR nama LIKE ?)";
    $search_param = "%" . $search . "%";
    $params_count[] = $search_param;
    $params_count[] = $search_param;
    $types_count .= "ss";
}

if ($jurusan_filter !== '') {
    $sql_count .= " AND jurusan = ?";
    $params_count[] = $jurusan_filter;
    $types_count .= "s";
}

$stmt_count = mysqli_prepare($koneksi, $sql_count);
if (!empty($params_count)) {
    mysqli_stmt_bind_param($stmt_count, $types_count, ...$params_count);
}
mysqli_stmt_execute($stmt_count);
$res_count = mysqli_stmt_get_result($stmt_count);
$total_data = ($res_count) ? mysqli_fetch_assoc($res_count)['total'] : 0;
$total_pages = ceil($total_data / $limit);
if ($total_pages < 1) $total_pages = 1;

// 4. Bangun Query Ambil Data Utama dengan Limit & Offset
$sql_data = "SELECT * FROM mahasiswa WHERE 1=1";
$params_data = [];
$types_data = "";

if ($search !== '') {
    $sql_data .= " AND (nim LIKE ? OR nama LIKE ?)";
    $params_data[] = $search_param;
    $params_data[] = $search_param;
    $types_data .= "ss";
}

if ($jurusan_filter !== '') {
    $sql_data .= " AND jurusan = ?";
    $params_data[] = $jurusan_filter;
    $types_data .= "s";
}

$sql_data .= " ORDER BY id DESC LIMIT ? OFFSET ?";
$params_data[] = $limit;
$params_data[] = $offset;
$types_data .= "ii";

$stmt_data = mysqli_prepare($koneksi, $sql_data);
mysqli_stmt_bind_param($stmt_data, $types_data, ...$params_data);
mysqli_stmt_execute($stmt_data);
$result = mysqli_stmt_get_result($stmt_data);

// 5. Ambil Daftar Jurusan untuk Dropdown Filter
$res_opt_jurusan = mysqli_query($koneksi, "SELECT DISTINCT jurusan FROM mahasiswa ORDER BY jurusan ASC");

// Catatan: Fungsi getJurusanBadgeClass() telah disediakan secara terpusat di koneksi.php

// Panggil Header Template
include_once 'includes/header.php';
?>

<!-- Alert Notifikasi Flash -->
<?php if (!empty($alert_msg)): ?>
    <div class="alert alert-<?= $alert_type ?>" role="alert">
        <div class="alert-content">
            <i class="fa-solid <?= ($alert_type == 'success') ? 'fa-circle-check alert-icon' : 'fa-circle-exclamation alert-icon' ?>"></i>
            <span><?= htmlspecialchars($alert_msg) ?></span>
        </div>
        <button type="button" class="alert-close" aria-label="Tutup notifikasi">
            <i class="fa-solid fa-xmark"></i>
        </button>
    </div>
<?php endif; ?>

<!-- Toolbar: Filter, Search, dan Tombol Tambah -->
<div class="toolbar-container">
    <form action="mahasiswa.php" method="GET" class="search-form">
        <!-- Input Pencarian -->
        <div class="search-input-wrapper">
            <i class="fa-solid fa-magnifying-glass"></i>
            <input type="text" name="search" class="form-control" 
                   placeholder="Cari berdasarkan NIM atau Nama Mahasiswa..." 
                   value="<?= htmlspecialchars($search) ?>" autocomplete="off">
        </div>

        <!-- Filter Dropdown Jurusan -->
        <select name="jurusan" class="form-control filter-select" onchange="this.form.submit()">
            <option value="">Semua Program Studi</option>
            <?php if ($res_opt_jurusan): ?>
                <?php while ($opt = mysqli_fetch_assoc($res_opt_jurusan)): ?>
                    <option value="<?= htmlspecialchars($opt['jurusan']) ?>" <?= ($jurusan_filter === $opt['jurusan']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($opt['jurusan']) ?>
                    </option>
                <?php endwhile; ?>
            <?php endif; ?>
        </select>

        <button type="submit" class="btn btn-primary btn-sm">
            <i class="fa-solid fa-filter"></i> Terapkan
        </button>

        <?php if (!empty($search) || !empty($jurusan_filter)): ?>
            <a href="mahasiswa.php" class="btn btn-secondary btn-sm" title="Reset Pencarian">
                <i class="fa-solid fa-rotate-left"></i> Reset
            </a>
        <?php endif; ?>
    </form>

    <div class="toolbar-actions">
        <a href="tambah.php" class="btn btn-primary">
            <i class="fa-solid fa-user-plus"></i> Tambah Mahasiswa
        </a>
    </div>
</div>

<!-- Card Tabel Utama Data Mahasiswa -->
<div class="card">
    <div class="card-header">
        <div class="card-title-group">
            <div class="card-header-icon">
                <i class="fa-solid fa-user-graduate"></i>
            </div>
            <div>
                <h3 class="card-title">Daftar Mahasiswa Terdaftar</h3>
                <p class="card-subtitle">
                    Menampilkan total <strong><?= number_format($total_data, 0, ',', '.') ?></strong> data mahasiswa dalam basis data
                </p>
            </div>
        </div>
        <div>
            <span style="font-size: 12.5px; color: #64748B; font-weight: 500;">
                Halaman <?= $page ?> dari <?= $total_pages ?>
            </span>
        </div>
    </div>

    <div class="card-body" style="padding: 0;">
        <div class="table-responsive">
            <table class="custom-table table-zebra">
                <thead>
                    <tr>
                        <th style="width: 60px; text-align: center;">No.</th>
                        <th style="width: 140px;">NIM</th>
                        <th>Nama Mahasiswa</th>
                        <th>Program Studi</th>
                        <th>Alamat Email</th>
                        <th style="width: 160px;">Ditambahkan</th>
                        <th style="width: 110px; text-align: center;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && mysqli_num_rows($result) > 0): ?>
                        <?php 
                        $no = $offset + 1;
                        while ($row = mysqli_fetch_assoc($result)): 
                            $tanggal = date('d M Y, H:i', strtotime($row['created_at']));
                        ?>
                            <tr>
                                <td style="text-align: center; font-weight: 600; color: #64748B;">
                                    <?= $no++ ?>
                                </td>
                                <td>
                                    <span class="nim-badge"><?= htmlspecialchars($row['nim']) ?></span>
                                </td>
                                <td>
                                    <strong style="color: #0F172A;"><?= htmlspecialchars($row['nama']) ?></strong>
                                </td>
                                <td>
                                    <span class="jurusan-badge <?= getJurusanBadgeClass($row['jurusan']) ?>">
                                        <i class="fa-solid fa-bookmark" style="font-size: 10px;"></i>
                                        <?= htmlspecialchars($row['jurusan']) ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="mailto:<?= htmlspecialchars($row['email']) ?>" class="email-link">
                                        <i class="fa-regular fa-envelope"></i>
                                        <?= htmlspecialchars($row['email']) ?>
                                    </a>
                                </td>
                                <td>
                                    <span class="date-text">
                                        <i class="fa-regular fa-calendar" style="font-size: 11px;"></i>
                                        <?= $tanggal ?>
                                    </span>
                                </td>
                                <td style="text-align: center;">
                                    <div class="action-group" style="justify-content: center;">
                                        <!-- Tombol Edit -->
                                        <a href="edit.php?id=<?= $row['id'] ?>" class="btn-action btn-action-edit" title="Edit Data Mahasiswa">
                                            <i class="fa-solid fa-pen-to-square"></i>
                                        </a>
                                        <!-- Tombol Hapus (Trigger Modal) -->
                                        <button type="button" class="btn-action btn-action-delete" 
                                                data-id="<?= $row['id'] ?>" 
                                                data-nama="<?= htmlspecialchars($row['nama']) ?>" 
                                                title="Hapus Data Mahasiswa">
                                            <i class="fa-solid fa-trash-can"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <!-- Tampilan Ketika Data Kosong / Hasil Pencarian Nihil -->
                        <tr>
                            <td colspan="7">
                                <div class="empty-state">
                                    <div class="empty-state-icon">
                                        <i class="fa-solid fa-magnifying-glass"></i>
                                    </div>
                                    <div class="empty-state-title">Data Mahasiswa Tidak Ditemukan</div>
                                    <p class="empty-state-desc">
                                        <?php if (!empty($search) || !empty($jurusan_filter)): ?>
                                            Tidak ada hasil yang sesuai dengan kriteria pencarian Anda. Silakan coba kata kunci lain atau reset filter.
                                        <?php else: ?>
                                            Belum ada data mahasiswa yang tersimpan di dalam basis data.
                                        <?php endif; ?>
                                    </p>
                                    <?php if (!empty($search) || !empty($jurusan_filter)): ?>
                                        <a href="mahasiswa.php" class="btn btn-secondary btn-sm">
                                            <i class="fa-solid fa-rotate-left"></i> Reset Pencarian
                                        </a>
                                    <?php else: ?>
                                        <a href="tambah.php" class="btn btn-primary btn-sm">
                                            <i class="fa-solid fa-plus"></i> Tambah Mahasiswa Baru
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Pagination Navigasi -->
    <?php if ($total_pages > 1): ?>
        <div class="pagination-container">
            <div class="pagination-info">
                Menampilkan <strong><?= min($offset + 1, $total_data) ?></strong> - <strong><?= min($offset + $limit, $total_data) ?></strong> dari <strong><?= $total_data ?></strong> mahasiswa
            </div>
            <nav class="pagination-nav">
                <!-- Tombol Sebelumnya -->
                <?php if ($page > 1): ?>
                    <a href="mahasiswa.php?page=<?= $page - 1 ?>&search=<?= urlencode($search) ?>&jurusan=<?= urlencode($jurusan_filter) ?>" class="page-btn">
                        <i class="fa-solid fa-chevron-left"></i>
                    </a>
                <?php else: ?>
                    <span class="page-btn disabled"><i class="fa-solid fa-chevron-left"></i></span>
                <?php endif; ?>

                <!-- Tombol Angka Halaman -->
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <a href="mahasiswa.php?page=<?= $i ?>&search=<?= urlencode($search) ?>&jurusan=<?= urlencode($jurusan_filter) ?>" 
                       class="page-btn <?= ($i == $page) ? 'active' : '' ?>">
                        <?= $i ?>
                    </a>
                <?php endfor; ?>

                <!-- Tombol Berikutnya -->
                <?php if ($page < $total_pages): ?>
                    <a href="mahasiswa.php?page=<?= $page + 1 ?>&search=<?= urlencode($search) ?>&jurusan=<?= urlencode($jurusan_filter) ?>" class="page-btn">
                        <i class="fa-solid fa-chevron-right"></i>
                    </a>
                <?php else: ?>
                    <span class="page-btn disabled"><i class="fa-solid fa-chevron-right"></i></span>
                <?php endif; ?>
            </nav>
        </div>
    <?php endif; ?>
</div>

<?php
include_once 'includes/footer.php';
?>
