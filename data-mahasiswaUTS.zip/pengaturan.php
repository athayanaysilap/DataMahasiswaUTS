<?php
/**
 * ========================================================
 * File: pengaturan.php
 * Deskripsi: Halaman Informasi Aplikasi, Administrator,
 *            Spesifikasi Sistem, dan Panduan Teknis CRUD.
 * Aplikasi: BlueStudent - Sistem Manajemen Data Mahasiswa
 * ========================================================
 */

require_once 'koneksi.php';

$page_title = "Pengaturan & Info Sistem";
$breadcrumb = "Pengaturan";

include_once 'includes/header.php';
?>

<div style="max-width: 1000px; margin: 0 auto;">
    <!-- Welcome Header Pengaturan -->
    <div class="card" style="margin-bottom: 24px; background: linear-gradient(135deg, #0B1F4D 0%, #1D4ED8 100%); color: #FFFFFF;">
        <div class="card-body" style="padding: 28px 32px; display: flex; align-items: center; justify-content: space-between; flex-wrap: gap: 20px;">
            <div>
                <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 8px;">
                    <span style="background: rgba(255,255,255,0.2); padding: 4px 12px; border-radius: 20px; font-size: 11.5px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px;">
                        Web Project
                    </span>
                    <span style="color: #7DD3FC; font-size: 13px; font-weight: 600;">Versi 1.0.0</span>
                </div>
                <h2 style="font-size: 22px; font-weight: 700; margin-bottom: 6px;">BlueStudent Academic Portal</h2>
                <p style="font-size: 13.5px; color: rgba(255,255,255,0.85); max-width: 600px;">
                    Aplikasi manajemen data mahasiswa modern berbasis PHP Native & MySQL, dikembangkan sebagai tugas individu mata kuliah Web Project lanjutan dari proyek POS Minimart.
                </p>
            </div>
            <div style="font-size: 56px; color: rgba(255,255,255,0.2); display: flex; align-items: center;">
                <i class="fa-solid fa-graduation-cap"></i>
            </div>
        </div>
    </div>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px;">
        <!-- Card: Profil Administrator -->
        <div class="card">
            <div class="card-header">
                <div class="card-title-group">
                    <div class="card-header-icon">
                        <i class="fa-solid fa-user-gear"></i>
                    </div>
                    <div>
                        <h3 class="card-title">Profil Administrator</h3>
                        <p class="card-subtitle">Akun pengelola sistem aktif</p>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div style="display: flex; align-items: center; gap: 18px; margin-bottom: 22px; padding-bottom: 18px; border-bottom: 1px solid var(--border-color);">
                    <div style="width: 58px; height: 58px; border-radius: 50%; background: var(--gradient-primary); color: #FFFFFF; display: flex; align-items: center; justify-content: center; font-size: 24px; font-weight: 700; box-shadow: 0 4px 12px rgba(37,99,235,0.3);">
                        AD
                    </div>
                    <div>
                        <h4 style="font-size: 16px; font-weight: 700; color: var(--navy-deep); margin-bottom: 2px;">Administrator Utama</h4>
                        <div style="font-size: 12.5px; color: var(--text-muted); margin-bottom: 6px;">admin@bluestudent.ac.id</div>
                        <span style="background: #ECFDF5; color: #059669; border: 1px solid #A7F3D0; font-size: 11px; font-weight: 700; padding: 2px 8px; border-radius: 12px; display: inline-flex; align-items: center; gap: 4px;">
                            <i class="fa-solid fa-circle-check"></i> Super Administrator
                        </span>
                    </div>
                </div>

                <table class="info-table">
                    <tr>
                        <td class="label-col">Hak Akses</td>
                        <td class="val-col">Full Access (CRUD Mahasiswa & Konfigurasi)</td>
                    </tr>
                    <tr>
                        <td class="label-col">Sesi Pengguna</td>
                        <td class="val-col">Active Session (Laragon Localhost)</td>
                    </tr>
                    <tr>
                        <td class="label-col">Mata Kuliah</td>
                        <td class="val-col"><strong>Web Project</strong></td>
                    </tr>
                    <tr>
                        <td class="label-col">Proyek Asal</td>
                        <td class="val-col">Pengembangan Proyek POS Minimart</td>
                    </tr>
                </table>
            </div>
        </div>

        <!-- Card: Spesifikasi Teknologi & Server -->
        <div class="card">
            <div class="card-header">
                <div class="card-title-group">
                    <div class="card-header-icon">
                        <i class="fa-solid fa-cubes-stacked"></i>
                    </div>
                    <div>
                        <h3 class="card-title">Stack Teknologi</h3>
                        <p class="card-subtitle">Teknologi pendukung aplikasi</p>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <table class="info-table">
                    <tr>
                        <td class="label-col">Frontend</td>
                        <td class="val-col">
                            <span class="badge-tech">HTML5</span>
                            <span class="badge-tech">CSS3 (Modern Gradient)</span>
                            <span class="badge-tech">JavaScript Vanilla</span>
                            <span class="badge-tech">Font Awesome 6</span>
                            <span class="badge-tech">Chart.js</span>
                        </td>
                    </tr>
                    <tr>
                        <td class="label-col">Backend</td>
                        <td class="val-col">
                            <span class="badge-tech">PHP <?= phpversion() ?> Native</span>
                            <span class="badge-tech">Procedural & Modular</span>
                        </td>
                    </tr>
                    <tr>
                        <td class="label-col">Database Engine</td>
                        <td class="val-col">
                            <span class="badge-tech">MySQL (InnoDB)</span>
                        </td>
                    </tr>
                    <tr>
                        <td class="label-col">Nama Database</td>
                        <td class="val-col"><code>db_mahasiswa</code></td>
                    </tr>
                    <tr>
                        <td class="label-col">Tabel Utama</td>
                        <td class="val-col"><code>mahasiswa</code></td>
                    </tr>
                    <tr>
                        <td class="label-col">Enkoding Charset</td>
                        <td class="val-col"><code>utf8mb4_unicode_ci</code></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>

    <!-- Card: Panduan Alur CRUD & Keamanan Sistem (Sangat Membantu saat Video Presentasi) -->
    <div class="card">
        <div class="card-header">
            <div class="card-title-group">
                <div class="card-header-icon" style="background: #ECFEFF; color: #0891B2;">
                    <i class="fa-solid fa-code-compare"></i>
                </div>
                <div>
                    <h3 class="card-title">Struktur Alur Logika CRUD & Keamanan</h3>
                    <p class="card-subtitle">Ringkasan teknis untuk penjelasan saat presentasi / rekaman video tugas</p>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 24px;">
                <div style="background: #F8FAFC; border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 16px;">
                    <div style="font-weight: 700; color: #1D4ED8; margin-bottom: 4px; display: flex; align-items: center; gap: 6px;">
                        <i class="fa-solid fa-circle-plus"></i> 1. CREATE
                    </div>
                    <div style="font-size: 12.5px; color: var(--text-body);">
                        File <code>tambah.php</code> memvalidasi input formulir di server, memeriksa duplikasi NIM, dan mengeksekusi <code>INSERT INTO mahasiswa ...</code> menggunakan Prepared Statements.
                    </div>
                </div>

                <div style="background: #F8FAFC; border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 16px;">
                    <div style="font-weight: 700; color: #0284C7; margin-bottom: 4px; display: flex; align-items: center; gap: 6px;">
                        <i class="fa-solid fa-eye"></i> 2. READ
                    </div>
                    <div style="font-size: 12.5px; color: var(--text-body);">
                        File <code>dashboard.php</code> dan <code>mahasiswa.php</code> menjalankan query <code>SELECT</code> dengan fitur pencarian teks, filter jurusan, statistik agregasi, dan pagination data.
                    </div>
                </div>

                <div style="background: #F8FAFC; border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 16px;">
                    <div style="font-weight: 700; color: #F59E0B; margin-bottom: 4px; display: flex; align-items: center; gap: 6px;">
                        <i class="fa-solid fa-pen-to-square"></i> 3. UPDATE
                    </div>
                    <div style="font-size: 12.5px; color: var(--text-body);">
                        File <code>edit.php</code> mengambil data berdasarkan parameter <code>id</code>, mengisi nilai form secara otomatis, dan memperbarui record dengan <code>UPDATE mahasiswa SET ...</code>.
                    </div>
                </div>

                <div style="background: #F8FAFC; border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 16px;">
                    <div style="font-weight: 700; color: #EF4444; margin-bottom: 4px; display: flex; align-items: center; gap: 6px;">
                        <i class="fa-solid fa-trash-can"></i> 4. DELETE
                    </div>
                    <div style="font-size: 12.5px; color: var(--text-body);">
                        File <code>hapus.php</code> meminta konfirmasi pengguna lewat modal interaktif sebelum mengeksekusi query <code>DELETE FROM mahasiswa WHERE id = ?</code>.
                    </div>
                </div>
            </div>

            <div style="background: #EFF6FF; border: 1px solid #BFDBFE; border-radius: var(--radius-md); padding: 18px 20px;">
                <h4 style="font-size: 14px; font-weight: 700; color: #1E40AF; margin-bottom: 6px; display: flex; align-items: center; gap: 8px;">
                    <i class="fa-solid fa-shield-halved"></i> Fitur Keamanan yang Diimplementasikan
                </h4>
                <ul style="font-size: 13px; color: #1E3A8A; margin-left: 20px; line-height: 1.6;">
                    <li><strong>SQL Injection Prevention:</strong> Seluruh query dinamis yang menerima parameter pengguna menggunakan <code>mysqli_prepare()</code>, <code>mysqli_stmt_bind_param()</code>, dan <code>mysqli_stmt_execute()</code>.</li>
                    <li><strong>Cross-Site Scripting (XSS) Prevention:</strong> Semua data string yang dicetak ke browser disanitasi menggunakan fungsi <code>htmlspecialchars(..., ENT_QUOTES, 'UTF-8')</code>.</li>
                    <li><strong>Server-Side Validation:</strong> Form input divalidasi ganda di sisi backend untuk memastikan email valid, NIM unik, dan nama terisi lengkap.</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php
include_once 'includes/footer.php';
?>

