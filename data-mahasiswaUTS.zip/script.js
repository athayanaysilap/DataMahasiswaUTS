/**
 * ========================================================
 * File: script.js
 * Deskripsi: Skrip interaktivitas UI, konfirmasi modal hapus,
 *            sidebar responsive toggle, dan auto-dismiss alert.
 * Aplikasi: BlueStudent - Sistem Manajemen Data Mahasiswa
 * ========================================================
 */

document.addEventListener('DOMContentLoaded', function () {
    // 1. Sidebar Toggle untuk Tampilan Mobile
    const sidebar = document.querySelector('.sidebar');
    const toggleBtn = document.querySelector('.sidebar-toggle-btn');

    if (toggleBtn && sidebar) {
        // Buat backdrop elemen jika di mobile
        const backdrop = document.createElement('div');
        backdrop.className = 'sidebar-backdrop';
        backdrop.style.cssText = `
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(11, 31, 77, 0.5);
            backdrop-filter: blur(2px);
            z-index: 999;
            display: none;
        `;
        document.body.appendChild(backdrop);

        toggleBtn.addEventListener('click', function () {
            sidebar.classList.toggle('show');
            backdrop.style.display = sidebar.classList.contains('show') ? 'block' : 'none';
        });

        backdrop.addEventListener('click', function () {
            sidebar.classList.remove('show');
            backdrop.style.display = 'none';
        });
    }

    // 2. Auto Dismiss Alert Notifikasi setelah 4 Detik
    const alertElements = document.querySelectorAll('.alert');
    alertElements.forEach(function (alert) {
        // Tombol Close manual
        const closeBtn = alert.querySelector('.alert-close');
        if (closeBtn) {
            closeBtn.addEventListener('click', function () {
                alert.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
                alert.style.opacity = '0';
                alert.style.transform = 'translateY(-10px)';
                setTimeout(() => alert.remove(), 300);
            });
        }

        // Auto fadeout
        setTimeout(function () {
            alert.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
            alert.style.opacity = '0';
            alert.style.transform = 'translateY(-10px)';
            setTimeout(() => alert.remove(), 400);
        }, 4500);
    });

    // 3. Modal Konfirmasi Hapus Data
    const modal = document.getElementById('deleteModal');
    const confirmDeleteBtn = document.getElementById('confirmDeleteBtn');
    const cancelDeleteBtn = document.getElementById('cancelDeleteBtn');
    const studentNameSpan = document.getElementById('modalStudentName');

    // Tangkap klik tombol hapus
    const deleteButtons = document.querySelectorAll('.btn-action-delete');
    deleteButtons.forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            e.preventDefault();
            const studentId = this.getAttribute('data-id');
            const studentName = this.getAttribute('data-nama');

            if (modal && confirmDeleteBtn) {
                studentNameSpan.textContent = studentName || 'mahasiswa ini';
                confirmDeleteBtn.href = `hapus.php?id=${studentId}`;
                modal.classList.add('active');
            } else {
                // Fallback jika modal tidak ada di halaman
                if (confirm(`Apakah Anda yakin ingin menghapus data mahasiswa "${studentName}"?`)) {
                    window.location.href = `hapus.php?id=${studentId}`;
                }
            }
        });
    });

    // Tutup modal saat klik tombol Batal atau backdrop modal
    if (cancelDeleteBtn && modal) {
        cancelDeleteBtn.addEventListener('click', function () {
            modal.classList.remove('active');
        });

        modal.addEventListener('click', function (e) {
            if (e.target === modal) {
                modal.classList.remove('active');
            }
        });
    }
});

