<?php
/**
 * ========================================================
 * File: tambah.php
 * Deskripsi: Halaman Tambah Mahasiswa Baru (Create)
 *            Validasi input server-side, cek duplikasi NIM,
 *            Prepared Statements INSERT.
 * Aplikasi: BlueStudent - Sistem Manajemen Data Mahasiswa
 * ========================================================
 */

require_once 'koneksi.php';

$page_title = "Tambah Mahasiswa";
$breadcrumb = "Tambah Mahasiswa";

// Inisialisasi variabel untuk form sticky & error
$nim = "";
$nama = "";
$jurusan = "";
$email = "";
$errors = [];

// Proses Form saat metode POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Ambil dan bersihkan data input
    $nim     = cleanInput($_POST['nim'] ?? '');
    $nama    = cleanInput($_POST['nama'] ?? '');
    $jurusan = cleanInput($_POST['jurusan'] ?? '');
    $email   = cleanInput($_POST['email'] ?? '');

    // 2. Validasi Server-Side
    if (empty($nim)) {
        $errors[] = "NIM mahasiswa wajib diisi.";
    } elseif (!preg_match('/^[0-9a-zA-Z\.\-_]{4,20}$/', $nim)) {
        $errors[] = "Format NIM tidak valid (hanya huruf, angka, 4-20 karakter).";
    }

    if (empty($nama)) {
        $errors[] = "Nama lengkap mahasiswa wajib diisi.";
    } elseif (strlen($nama) < 3) {
        $errors[] = "Nama mahasiswa minimal terdiri dari 3 karakter.";
    }

    if (empty($jurusan)) {
        $errors[] = "Program studi / jurusan wajib dipilih.";
    }

    if (empty($email)) {
        $errors[] = "Alamat email mahasiswa wajib diisi.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Format penulisan email tidak valid (contoh: mahasiswa@student.ac.id).";
    }

    // 3. Cek apakah NIM sudah terdaftar (Pencegahan Duplikasi NIM)
    if (empty($errors)) {
        $check_sql = "SELECT id FROM mahasiswa WHERE nim = ? LIMIT 1";
        $stmt_check = mysqli_prepare($koneksi, $check_sql);
        mysqli_stmt_bind_param($stmt_check, "s", $nim);
        mysqli_stmt_execute($stmt_check);
        mysqli_stmt_store_result($stmt_check);

        if (mysqli_stmt_num_rows($stmt_check) > 0) {
            $errors[] = "NIM <strong>" . htmlspecialchars($nim) . "</strong> sudah digunakan oleh mahasiswa lain. Masukkan NIM yang unik.";
        }
        mysqli_stmt_close($stmt_check);
    }

    // 4. Jika validasi lolos, simpan ke database dengan Prepared Statement
    if (empty($errors)) {
        $insert_sql = "INSERT INTO mahasiswa (nim, nama, jurusan, email) VALUES (?, ?, ?, ?)";
        $stmt_insert = mysqli_prepare($koneksi, $insert_sql);
        
        if ($stmt_insert) {
            mysqli_stmt_bind_param($stmt_insert, "ssss", $nim, $nama, $jurusan, $email);
            
            if (mysqli_stmt_execute($stmt_insert)) {
                mysqli_stmt_close($stmt_insert);
                // Redirect ke halaman Data Mahasiswa dengan notifikasi sukses
                header("Location: mahasiswa.php?status=sukses_tambah");
                exit;
            } else {
                $errors[] = "Gagal menyimpan data ke database: " . mysqli_error($koneksi);
            }
            mysqli_stmt_close($stmt_insert);
        } else {
            $errors[] = "Terjadi kesalahan pada prepared statement server.";
        }
    }
}

// Daftar Pilihan Jurusan Populer
$daftar_jurusan = [
    'Teknik Informatika',
    'Sistem Informasi',
    'Teknik Komputer',
    'Manajemen Informatika',
    'Rekayasa Perangkat Lunak',
    'Sains Data',
    'Teknologi Informasi',
    'Ilmu Komunikasi'
];

include_once 'includes/header.php';
?>

<div style="max-width: 780px; margin: 0 auto;">
    <!-- Alert Jika Ada Pesan Kesalahan Validasi -->
    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger" role="alert">
            <div class="alert-content">
                <i class="fa-solid fa-triangle-exclamation alert-icon"></i>
                <div>
                    <strong>Perhatian!</strong> Harap perbaiki beberapa isian berikut:
                    <ul style="margin: 6px 0 0 18px; list-style-type: disc;">
                        <?php foreach ($errors as $error): ?>
                            <li><?= $error ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
            <button type="button" class="alert-close" aria-label="Tutup notifikasi">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
    <?php endif; ?>

    <!-- Card Form Tambah Mahasiswa -->
    <div class="card">
        <div class="card-header" style="background: linear-gradient(135deg, #F8FAFC 0%, #EFF6FF 100%);">
            <div class="card-title-group">
                <div class="card-header-icon" style="background: var(--blue-primary); color: #FFFFFF;">
                    <i class="fa-solid fa-user-plus"></i>
                </div>
                <div>
                    <h3 class="card-title">Form Pendaftaran Mahasiswa</h3>
                    <p class="card-subtitle">Lengkapi formulir di bawah ini untuk mendaftarkan data mahasiswa baru</p>
                </div>
            </div>
            <a href="mahasiswa.php" class="btn btn-secondary btn-sm">
                <i class="fa-solid fa-arrow-left"></i> Kembali ke Daftar
            </a>
        </div>

        <div class="card-body" style="padding: 32px 36px;">
            <form action="tambah.php" method="POST" novalidate>
                <!-- Field NIM -->
                <div class="form-group">
                    <label for="nim" class="form-label">
                        Nomor Induk Mahasiswa (NIM) <span class="required">*</span>
                    </label>
                    <input type="text" id="nim" name="nim" class="form-control" 
                           placeholder="Contoh: 2301010088" 
                           value="<?= htmlspecialchars($nim) ?>" 
                           maxlength="20" required autofocus>
                    <div class="form-help">
                        <i class="fa-solid fa-circle-info"></i> NIM harus bersifat unik dan belum terdaftar di sistem.
                    </div>
                </div>

                <!-- Field Nama Lengkap -->
                <div class="form-group">
                    <label for="nama" class="form-label">
                        Nama Lengkap Mahasiswa <span class="required">*</span>
                    </label>
                    <input type="text" id="nama" name="nama" class="form-control" 
                           placeholder="Masukkan nama lengkap mahasiswa..." 
                           value="<?= htmlspecialchars($nama) ?>" 
                           maxlength="100" required>
                    <div class="form-help">
                        <i class="fa-solid fa-circle-info"></i> Masukkan nama sesuai dengan data identitas resmi / KTP.
                    </div>
                </div>

                <!-- Field Jurusan -->
                <div class="form-group">
                    <label for="jurusan" class="form-label">
                        Program Studi / Jurusan <span class="required">*</span>
                    </label>
                    <select id="jurusan" name="jurusan" class="form-control" required>
                        <option value="">-- Pilih Program Studi --</option>
                        <?php foreach ($daftar_jurusan as $jrs): ?>
                            <option value="<?= htmlspecialchars($jrs) ?>" <?= ($jurusan === $jrs) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($jrs) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <div class="form-help">
                        <i class="fa-solid fa-circle-info"></i> Pilih jurusan yang sedang ditempuh mahasiswa.
                    </div>
                </div>

                <!-- Field Email -->
                <div class="form-group">
                    <label for="email" class="form-label">
                        Alamat Email Mahasiswa <span class="required">*</span>
                    </label>
                    <input type="email" id="email" name="email" class="form-control" 
                           placeholder="nama.mahasiswa@student.ac.id" 
                           value="<?= htmlspecialchars($email) ?>" 
                           maxlength="100" required>
                    <div class="form-help">
                        <i class="fa-solid fa-circle-info"></i> Gunakan email aktif kampus atau email pribadi resmi.
                    </div>
                </div>

                <!-- Tombol Aksi Simpan & Batal -->
                <div class="form-actions">
                    <a href="mahasiswa.php" class="btn btn-secondary">
                        <i class="fa-solid fa-xmark"></i> Batal
                    </a>
                    <button type="submit" class="btn btn-primary" style="min-width: 150px;">
                        <i class="fa-solid fa-floppy-disk"></i> Simpan Data
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
include_once 'includes/footer.php';
?>

